package modex;

import java.math.BigInteger;

public class FastModularExponentiation {

	public static BigInteger fastModularExponentiation(BigInteger base, BigInteger power, BigInteger modulus) {
		if (modulus.equals(BigInteger.ONE)) {
			return BigInteger.ZERO;
		}
		BigInteger result = BigInteger.ONE;
		for (BigInteger i = BigInteger.ZERO; i.compareTo(power) == -1; i = i.add(BigInteger.ONE)) {
			result = result.multiply(base).mod(modulus);
		}
		return result;
	}
	
	public static void main(String[] args) {
		System.out.println("Fast modular exponentiation of 4222 to 1333 (mod 4957)");
		double startTime = System.nanoTime();
		System.out.println(fastModularExponentiation(new BigInteger("4222"), new BigInteger("1333"), new BigInteger("4957")));
		double endTime = System.nanoTime();
		System.out.println("Calculation took: " + (endTime - startTime)/ 1e6 + " milliseconds.");
		System.out.println("Fast modular exponentiation of 5 to 3 (mod 35)");
		double startTime1 = System.nanoTime();
		System.out.println(fastModularExponentiation(new BigInteger("5"), new BigInteger("3"), new BigInteger("35")));
		double endTime1 = System.nanoTime();
		System.out.println("Calculation took: " +(endTime1 - startTime1)/ 1e6 + " milliseconds.");
	}
}
